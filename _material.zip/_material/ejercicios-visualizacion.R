# Asegurate de revisar la sección de Prepara tu espacio para instalar los paquetes
library(tidyverse)
library(estcomp)

#### Visualización
ggplot(election_sub_2012) +
  geom_point(aes(x = total, y = prd_pt_mc, color = polling_type))

# Ej: Modifica el código anterior para experimentar con los aesthetics color (color),
# tamaño (size) y forma (shape).

# Boxplots
ggplot(election_sub_2012, aes(x = reorder(state_abbr, prd_pt_mc), 
                              y = prd_pt_mc)) +
  geom_jitter(size = 0.5) +
  geom_boxplot()
# Ej: Lee la ayuda de reorder y repite las gráficas anteriores ordenando por la mediana de prd_pt_mc.